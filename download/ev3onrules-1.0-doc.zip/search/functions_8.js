var searchData=
[
  ['motor',['Motor',['../classetrobo_1_1_motor.html#a47d018192a358e400238fde8f03b4001',1,'etrobo::Motor::Motor(Type type)'],['../classetrobo_1_1_motor.html#a7cca513d1b103a0f8c49c7c3c73cd23d',1,'etrobo::Motor::Motor(const Motor &amp;motor)=delete']]]
];
