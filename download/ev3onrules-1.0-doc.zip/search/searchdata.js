var indexSectionsWithContent =
{
  0: "bcdefgilmnoprstuw~",
  1: "bcdeflmrs",
  2: "bcdefgilmnoprsw~",
  3: "bct",
  4: "bdegloru"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "enums",
  4: "enumvalues"
};

var indexSectionLabels =
{
  0: "全て",
  1: "クラス",
  2: "関数",
  3: "列挙型",
  4: "列挙値"
};

