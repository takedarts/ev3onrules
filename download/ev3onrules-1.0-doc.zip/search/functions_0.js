var searchData=
[
  ['body',['Body',['../classetrobo_1_1_body.html#aa1aa8f4e9a396f034acc3904de5ddd05',1,'etrobo::Body::Body()'],['../classetrobo_1_1_body.html#a49fd640ad20fa95c6d02e0165f1c104d',1,'etrobo::Body::Body(const Body &amp;body)=delete']]],
  ['bytebuffer',['ByteBuffer',['../classetrobo_1_1_byte_buffer.html#ab39d8b12974cb6355ca97047e4bae1fb',1,'etrobo::ByteBuffer::ByteBuffer(uint32_t size)'],['../classetrobo_1_1_byte_buffer.html#aca55fe4d720142c81d84fea5c83ce176',1,'etrobo::ByteBuffer::ByteBuffer(const ByteBuffer &amp;byteBuffer)=delete']]]
];
