var searchData=
[
  ['exception',['Exception',['../classetrobo_1_1_exception.html#a4df303f9be5e4e2eca3616b032a235c3',1,'etrobo::Exception::Exception(const char *what)'],['../classetrobo_1_1_exception.html#aa96016ebc6c63ef0a2346124342a7091',1,'etrobo::Exception::Exception(const std::string what)']]]
];
