var searchData=
[
  ['sensor',['Sensor',['../classetrobo_1_1_sensor.html',1,'etrobo']]],
  ['sensor',['Sensor',['../classetrobo_1_1_sensor.html#a2d9fc64903cf8e230992df6217c71a48',1,'etrobo::Sensor::Sensor()'],['../classetrobo_1_1_sensor.html#a49a29177e22045c4a7f133d1067fb276',1,'etrobo::Sensor::Sensor(const Sensor &amp;sensor)=delete']]],
  ['setledcolor',['setLedColor',['../classetrobo_1_1_body.html#a209634d54ea8c2e0c8abae4acc0fd144',1,'etrobo::Body']]],
  ['setpower',['setPower',['../classetrobo_1_1_motor.html#a4b16f042064335af567586332f92ccdf',1,'etrobo::Motor']]],
  ['setrotate',['setRotate',['../classetrobo_1_1_motor.html#abb2a209c73237fd9a860ab7a30bb5406',1,'etrobo::Motor']]]
];
