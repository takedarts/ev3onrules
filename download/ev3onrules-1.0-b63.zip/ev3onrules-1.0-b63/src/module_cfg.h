#pragma once
extern ID _module_id_APP_INIT_TASK;
#define APP_INIT_TASK ((const ID)(_module_id_APP_INIT_TASK))

extern ID _module_id_BOOT_TASK;
#define BOOT_TASK ((const ID)(_module_id_BOOT_TASK))

extern ID _module_id_RUN_TASK;
#define RUN_TASK ((const ID)(_module_id_RUN_TASK))

extern ID _module_id_COM_TASK;
#define COM_TASK ((const ID)(_module_id_COM_TASK))

extern ID _module_id_FLG;
#define FLG ((const ID)(_module_id_FLG))

extern ID _module_id_MTX;
#define MTX ((const ID)(_module_id_MTX))

